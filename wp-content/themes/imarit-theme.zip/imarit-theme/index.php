<?php get_header(); ?>

<?php the_content(); ?>

<?php get_footer(); ?>